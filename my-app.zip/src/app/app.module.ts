import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeListComponent } from 'src/app/employee/employee-list.component';
import { EmpDetailComponent } from './employee/emp-detail/emp-detail.component';
import { WelcomeComponentComponent } from './welcome-component/welcome-component.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    EmployeeComponent,
    EmployeeListComponent,
    EmpDetailComponent,
    WelcomeComponentComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot([
      {path: 'employee', component:EmployeeListComponent},
      {path: 'employee/:id', component:EmpDetailComponent},
      {path: 'welcome', component:WelcomeComponentComponent},
      {path: 'addEmployee', component:EmployeeComponent},
      {path: '',redirectTo:'welcome',pathMatch:'full'},
      {path: '**',redirectTo:'welcome',pathMatch:'full'}
        
    ], { useHash:true})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
