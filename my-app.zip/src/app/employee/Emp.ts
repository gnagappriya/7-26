export class Emp{
empid : string;
empname : string;
address : string;
email : string;
salary : string;
rating : string;
}